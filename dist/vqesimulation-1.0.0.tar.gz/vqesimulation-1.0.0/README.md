# Tesis project
Project to get a degree in computer science.

The main idea is implement a few variational quantum algorithms to study condensed matter and chemistry models and give a basic template to study complex phenomena. This project didnt want to be another quantum library. This should be see as a high level implementation to study systems with a fixed route to be executed, so, the user only need to give the parameters and just the minimun programming is needed (in the demo it's possible to see the code structure). 

# Requirements
It's recommended create a virtual enviroment and install all the libraries indicated in the requiremets.txt. 

``` pip3 install -r requirements.txt ```

# Methods
The main two methods are the following.

1. Variational quantum eigensolver
2. Variational quantum deflation

There are more quantities to calculate with the states.
More information in the repository wiki.
