#from .funciones import *
from .scipy_opt import *
from .gradient_opt import *
from .adap_opt import *